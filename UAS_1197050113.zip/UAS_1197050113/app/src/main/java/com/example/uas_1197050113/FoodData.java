package com.example.uas_1197050113;

import android.content.Context;

import java.util.ArrayList;

public class FoodData {


    public static ArrayList<Integer> getGambar(){
        ArrayList<Integer> drawables = new ArrayList<Integer>();
        drawables.add(R.drawable.cappuchino);
        drawables.add(R.drawable.cireng);
        drawables.add(R.drawable.donut);
        drawables.add(R.drawable.mie_goreng);
        drawables.add(R.drawable.batagor);
        drawables.add(R.drawable.black_salad);

        return drawables;
    }

    public static ArrayList<Food> getData(Context context) {
        ArrayList<Food> list = new ArrayList<Food>();
        list.add(new Food("Cappuchino", "Merupakan minuman halal beraneka ragam rasa", "Rp. 15000", context.getDrawable(R.drawable.cappuchino)));
        list.add(new Food("Cireng", "Cireng adalah makanan ringan dan halal.", "Rp. 1000", context.getDrawable(R.drawable.cireng)));
        list.add(new Food("Donut", "Donat adalah adonan yang digoreng, dibuat dari adonan tepung terigu, gula, telur, dan mentega. dam pastinya halal.", "Rp.3000", context.getDrawable(R.drawable.donut)));
        list.add(new Food("Mie Goreng", "Mie Goreng adalah makanan yang berasal dari Indonesia yang populer dan juga digemari di Malaysia, dan Singapura. Banyakdisukai karena Halal.","Rp. 7000", context.getDrawable(R.drawable.mie_goreng)));
        list.add(new Food("Batagor", "Batagor merupakan jajanan khas Bandung yang mengadaptasi gaya Tionghoa-Indonesia dan kini sudah dikenal hampir di seluruh wilayah Indonesia. Secara umum, batagor dibuat dari tahu yang dilembutkan dan diisi dengan adonan berbahan ikan tenggiri[2] dan tepung tapioka lalu dibentuk menyerupai bola yang digoreng dalam minyak panas selama beberapa menit hingga matang. ", "Rp. 5000", context.getDrawable(R.drawable.batagor)));
        list.add(new Food("Black Salad", "Black Salad adalah makanan baru yang banyak diminati, dinamakan black salad Karena ada kandungan charcoal yang memiliki fungsi yang baik untuk tubuh kita, antara lain mencegah kembung dan menurunkan kolesterol.", "Rp. 25000", context.getDrawable(R.drawable.black_salad)));
     
        return list;
    }
}