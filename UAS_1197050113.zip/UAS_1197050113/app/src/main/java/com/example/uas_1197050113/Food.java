package com.example.uas_1197050113;

import android.graphics.drawable.Drawable;

public class Food {
    String judul;
    String deskripsi;
    String harga;
    Drawable image;

    Food(String judul, String deskripsi, String harga, Drawable image) {
        this.judul = judul;
        this.deskripsi = deskripsi;
        this.harga = harga;
        this.image = image;
    }
}